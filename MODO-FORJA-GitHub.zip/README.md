# MODO FORJA

Aplicativo da Forja Mental empacotado com Capacitor.

## Gerar o APK pelo GitHub

1. Envie estes arquivos para um repositório GitHub.
2. Entre na aba **Actions**.
3. Execute **Build MODO FORJA Android**.
4. Quando terminar, abra a execução e baixe o artefato **MODO-FORJA-APK**.

## Gerar localmente

```bash
npm install
npx cap add android
npx cap sync android
cd android
./gradlew assembleDebug
```

APK: `android/app/build/outputs/apk/debug/app-debug.apk`

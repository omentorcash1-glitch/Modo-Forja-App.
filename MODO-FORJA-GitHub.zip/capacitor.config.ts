import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.forjamental.modoforja',
  appName: 'MODO FORJA',
  webDir: 'www',
  bundledWebRuntime: false
};

export default config;
